package TwentyFortyEight;

public class Cell {

    private int x;
    private int y;

    public Cell(int x, int y) {

    }

}